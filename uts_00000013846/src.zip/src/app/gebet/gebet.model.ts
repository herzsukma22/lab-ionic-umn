export class Gebet {
    constructor(
        public id: string,
        public name: string,
        public description: string,
        public gender: string
    ) {}
}